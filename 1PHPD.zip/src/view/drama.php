<?php include 'header.php'; ?>

<?php include '../model/MovieDrama.php'; ?>

<?php include '../model/User.php'; ?>

<?php include 'footer.php'; ?>
