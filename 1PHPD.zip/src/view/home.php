<?php include 'header.php'; ?>

<?php include '../model/MovieHome.php'; ?>

<?php include 'footer.php'; ?>