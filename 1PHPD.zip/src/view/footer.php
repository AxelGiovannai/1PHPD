<footer class="bg-bleu6 text-bleu1 p-4 mt-auto">
    <p class="text-center">© 2024 Internet Movies DataBase & Co. Tous droits réservés.</p>
</footer>
</body>

</html>