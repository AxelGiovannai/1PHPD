<?php include 'header.php'; ?>


<?php include '../model/DetailsDisplay.php'; ?>


<?php include 'footer.php'; ?>