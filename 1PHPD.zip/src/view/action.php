<?php include 'header.php'; ?>

<?php include '../model/User.php'?>

<?php include '../model/MovieAction.php'; ?>

<?php include 'footer.php'; ?>
